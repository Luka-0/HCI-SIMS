﻿using InitialProject.Controller;
using InitialProject.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InitialProject.ViewModel
{
    public class VoucherViewModel:BindableBase
    {
        private VoucherController voucherController = new VoucherController();

        private ObservableCollection<Voucher> _vouchers;

        private Voucher _selectedRowData;
        public VoucherViewModel()
        {
            LoadData();

            UpdateHeaderTitle("Pregled svih vaucera");
            UpdateFooterParametar("home");
        }

        public ObservableCollection<Voucher> Vouchers
        {
            get { return _vouchers; }
            set
            {
                if (_vouchers != value)
                {
                    _vouchers = value;
                    OnPropertyChanged(nameof(Vouchers));
                }
            }
        }

        public Voucher SelectedRowData
        {
            get { return _selectedRowData; }
            set
            {
                if (_selectedRowData != value)
                {
                    _selectedRowData = value;
                    OnPropertyChanged(nameof(SelectedRowData));
                }
            }
        }

        public void LoadData()
        {
            ObservableCollection<Voucher> vouchers = new ObservableCollection<Voucher>();
            List<Voucher> tempVouchers = voucherController.GetAll();

            foreach (Voucher voucher in tempVouchers)
            {
                vouchers.Add(voucher);
            }
            Vouchers = vouchers;
        }








    }
}
