﻿using GalaSoft.MvvmLight.Messaging;
using InitialProject.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace InitialProject.ViewModel
{
    public class ReserveTourViewModel:BindableBase
    {
        private double _sliderValue = 0;
        private string _sliderLabelText = "Broj gostiju: 0";
        private string _selectedTourId;
        public MyICommand DecreaseSliderValue { get; set; }
        public MyICommand IncreaseSliderValue { get; set; }

        public ReserveTourViewModel()
        {
            Mediator.Instance.Subscribe("TourIndexUpdated", OnTourIndexUpdated);

            DecreaseSliderValue = new MyICommand(OnDecreaseSliderValue);
            IncreaseSliderValue = new MyICommand(OnIncreaseSliderValue);
        }
        public string SelectedTourId
        {
            get { return _selectedTourId; }
            set
            {
                _selectedTourId = value;
                OnPropertyChanged(nameof(_selectedTourId));
            }
        }

        public double SliderValue
        {
            get { return _sliderValue; }
            set
            {
                _sliderValue = value;
                _sliderLabelText = "Broj gostiju: " + _sliderValue.ToString();
                OnPropertyChanged(nameof(SliderValue));
                OnPropertyChanged(nameof(SliderLabelText));
            }
        }

        public string SliderLabelText
        {
            get { return _sliderLabelText; }
            set
            {
                _sliderLabelText = value;
                OnPropertyChanged(nameof(SliderLabelText));
            }
        }

        public void OnDecreaseSliderValue()
        {
            if(SliderValue - 1 > 0)
            {
                SliderValue--;
            }
        }

        public void OnIncreaseSliderValue()
        {
            SliderValue++;
        }

        private void OnTourIndexUpdated(object newId)
        {
            SelectedTourId = newId as string;
        }

    }
}
