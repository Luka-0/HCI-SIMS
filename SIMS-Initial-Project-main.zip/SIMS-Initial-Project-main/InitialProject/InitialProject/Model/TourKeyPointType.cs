﻿namespace InitialProject.Model;

public enum TourKeyPointType
{
    Start,
    Mid,
    End,
    
}