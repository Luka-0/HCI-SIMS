﻿

namespace InitialProject.Enumeration
{
    public enum AccommodationType
    {
        Apartment,
        Accommodation,
        House,
        Cottage,
    }
}
