﻿namespace InitialProject.Enumeration;

public enum TourStatus
{
    Waiting,
    Started,
    Finished
}