﻿namespace InitialProject.Enumeration;

public enum TourRequestState
{
    Pending,
    Invalid,
    Accepted
}