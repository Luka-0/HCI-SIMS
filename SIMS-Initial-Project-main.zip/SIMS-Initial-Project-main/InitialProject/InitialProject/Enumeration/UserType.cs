﻿namespace InitialProject.Enumeration;

public enum UserType
{
    Guest1,
    Guest2,
    Guide,
    Owner
}