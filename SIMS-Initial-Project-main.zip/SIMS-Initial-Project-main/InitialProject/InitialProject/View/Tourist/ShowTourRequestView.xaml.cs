﻿using InitialProject.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace InitialProject.View.Tourist
{
    /// <summary>
    /// Interaction logic for ShowTourRequestView.xaml
    /// </summary>
    public partial class ShowTourRequestView : UserControl
    {
        public ShowTourRequestView()
        {
            InitializeComponent();
            this.DataContext = new ShowTourRequestViewModel();
        }
    }
}
